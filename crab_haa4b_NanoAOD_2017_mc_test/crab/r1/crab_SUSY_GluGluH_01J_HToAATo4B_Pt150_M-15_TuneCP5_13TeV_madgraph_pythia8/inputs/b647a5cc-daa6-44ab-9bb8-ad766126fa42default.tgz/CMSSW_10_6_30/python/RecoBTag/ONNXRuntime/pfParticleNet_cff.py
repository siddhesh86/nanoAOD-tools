import FWCore.ParameterSet.Config as cms

from RecoBTag.FeatureTools.pfDeepBoostedJetTagInfos_cfi import pfDeepBoostedJetTagInfos
from RecoBTag.ONNXRuntime.boostedJetONNXJetTagsProducer_cfi import boostedJetONNXJetTagsProducer
from RecoBTag.ONNXRuntime.pfParticleNetDiscriminatorsJetTags_cfi import pfParticleNetDiscriminatorsJetTags
from RecoBTag.ONNXRuntime.pfMassDecorrelatedParticleNetDiscriminatorsJetTags_cfi import pfMassDecorrelatedParticleNetDiscriminatorsJetTags

pfParticleNetTagInfos = pfDeepBoostedJetTagInfos.clone(
    use_puppiP4 = False
)

pfParticleNetJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/General/V01/preprocess.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/General/V01/particle-net.onnx',
    flav_names = ["probTbcq",  "probTbqq",  "probTbc",   "probTbq",  "probTbel", "probTbmu", "probTbta",
                  "probWcq",   "probWqq",   "probZbb",   "probZcc",  "probZqq",  "probHbb", "probHcc",
                  "probHqqqq", "probQCDbb", "probQCDcc", "probQCDb", "probQCDc", "probQCDothers"],
)

pfMassDecorrelatedParticleNetJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/MD-2prong/V01/preprocess.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/MD-2prong/V01/particle-net.onnx',
    flav_names = ["probXbb", "probXcc", "probXqq", "probQCDbb", "probQCDcc",
                  "probQCDb", "probQCDc", "probQCDothers"],
)

pfPNetXto4bv1JetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/MD-Hto4b/V01/preprocess_multiclass_wH-70_E30_AWB_2023_08_31_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/MD-Hto4b/V01/multiclass_wH-70_E30_AWB_2023_08_31_v12.onnx',
    flav_names = ["probHaa4b", "probHaa3b", "probHaa2b", "probHaa01b",
                  "probQCD4b", "probQCD3b", "probQCD2b", "probQCD1b", "probQCD0b"],
)

pfPNetXto4bv2aJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/MD-Hto4b/V02/ultraclass_wH-70_wgt05_E30_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/MD-Hto4b/V02/ultraclass_wH-70_wgt05_E30_AWB_2024_06_04_v12.onnx',
    flav_names = ["probHaa4b", "probHaa3b", "probHaa2b", "probHaa01b",
                  "probQCD4b", "probQCD3b", "probQCD2b2c", "probQCD2b", "probQCD1b", "probQCD0b",
                  "probNR4b", "probNR3b", "probNR2b2c", "probNR2b", "probNR1b", "probNR0b", "probNRlep"],
)

pfPNetXto4bv2bJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/MD-Hto4b/V02/ultraclass_wH-70_wgt02_E20_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/MD-Hto4b/V02/ultraclass_wH-70_wgt02_E20_AWB_2024_06_04_v12.onnx',
    flav_names = ["probHaa4b", "probHaa3b", "probHaa2b", "probHaa01b",
                  "probQCD4b", "probQCD3b", "probQCD2b2c", "probQCD2b", "probQCD1b", "probQCD0b",
                  "probNR4b", "probNR3b", "probNR2b2c", "probNR2b", "probNR1b", "probNR0b", "probNRlep"],
)

pfPNetTTtoHadJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/MD-Hto4b/V02/ultraclass_TT_E30_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/MD-Hto4b/V02/ultraclass_TT_E30_AWB_2024_06_04_v12.onnx',
    flav_names = ["probQCD0b", "probQCD1b", "probQCD2c", "probQCD2b",
                  "probX0b", "probX1b", "probX2c", "probX2b", "probX3q", "probX4q",
                  "probT1b2q", "probT1bb2q", "probT1bbb2q", "probT1b3q",
                  "probT2b1q", "probT2b2q", "probTTHad"],
)

pfParticleNetMassRegressionJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/MassRegression/V01/preprocess.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/MassRegression/V01/particle-net.onnx',
    flav_names = ["mass"],
)

pfPNetHto4bMassHv1JetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionH/V01/preprocess_wide_H_calc_mass_regr_loss3_Si_AWB_2023_09_14_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionH/V01/wide_H_calc_mass_regr_loss3_Si_AWB_2023_09_14_v12.onnx',
    flav_names = ["outputHv1"],
)

pfPNetHto4bMassHv2aJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionH/V02/MH-regr_mass_mode3_wH-70_E15_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionH/V02/MH-regr_mass_mode3_wH-70_E15_AWB_2024_06_04_v12.onnx',
    flav_names = ["outputHv2a"],
)

pfPNetHto4bMassHv2bJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionH/V02/MH-regr_mass_mode0_wH-70_E15_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionH/V02/MH-regr_mass_mode0_wH-70_E15_AWB_2024_06_04_v12.onnx',
    flav_names = ["outputHv2b"],
)

pfPNetHto4bMassHv2cJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionH/V02/MH-regr_logMass_mode3_wH-70_E15_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionH/V02/MH-regr_logMass_mode3_wH-70_E15_AWB_2024_06_04_v12.onnx',
    flav_names = ["outputHv2c"],
)

pfPNetHto4bMassHv2dJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionH/V02/MH-regr_logMass_mode0_wH-70_E15_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionH/V02/MH-regr_logMass_mode0_wH-70_E15_AWB_2024_06_04_v12.onnx',
    flav_names = ["outputHv2d"],
)

pfPNetHto4bMassAaJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_4b_mass_mode3_mH-125_E20_Si_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_4b_mass_mode3_mH-125_E20_Si_2024_06_04_v12.onnx',
    flav_names = ["outputAa"],
)

pfPNetHto4bMassAbJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_4b_mass_mode0_mH-125_E20_Si_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_4b_mass_mode0_mH-125_E20_Si_2024_06_04_v12.onnx',
    flav_names = ["outputAb"],
)

pfPNetHto4bMassAcJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_4b_logMass_mode3_mH-125_E20_Si_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_4b_logMass_mode3_mH-125_E20_Si_2024_06_04_v12.onnx',
    flav_names = ["outputAc"],
)

pfPNetHto4bMassAdJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_4b_logMass_mode0_mH-125_E20_Si_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_4b_logMass_mode0_mH-125_E20_Si_2024_06_04_v12.onnx',
    flav_names = ["outputAd"],
)

pfPNetHto34bMassAaJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_34b_mass_mode3_mH-125_E20_Si_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_34b_mass_mode3_mH-125_E20_Si_2024_06_04_v12.onnx',
    flav_names = ["outputAa"],
)

pfPNetHto34bMassAbJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_34b_mass_mode0_mH-125_E20_Si_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_34b_mass_mode0_mH-125_E20_Si_2024_06_04_v12.onnx',
    flav_names = ["outputAb"],
)

pfPNetHto34bMassAcJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_34b_logMass_mode3_mH-125_E20_Si_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_34b_logMass_mode3_mH-125_E20_Si_2024_06_04_v12.onnx',
    flav_names = ["outputAc"],
)

pfPNetHto34bMassAdJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_34b_logMass_mode0_mH-125_E20_Si_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA-regr_34b_logMass_mode0_mH-125_E20_Si_2024_06_04_v12.onnx',
    flav_names = ["outputAd"],
)

pfPNetHto4bMassA1JetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA1-regr_bbbar_dR_mass_mode3_wH-70_E10_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA1-regr_bbbar_dR_mass_mode3_wH-70_E10_AWB_2024_06_04_v12.onnx',
    flav_names = ["outputA1"],
)

pfPNetHto4bMassA2JetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA2-regr_bbbar_dR_mass_mode3_wH-70_E10_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MA2-regr_bbbar_dR_mass_mode3_wH-70_E10_AWB_2024_06_04_v12.onnx',
    flav_names = ["outputA2"],
)

pfPNetHto4bMassAAJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MAA-regr_mass_mode3_wH-70_E15_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/MAA-regr_mass_mode3_wH-70_E15_AWB_2024_06_04_v12.onnx',
    flav_names = ["outputAA"],
)

pfPNetHto4bMassDiffAAJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/logDiffAA_regr_E15_mode3_wH-70_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/logDiffAA_regr_E15_mode3_wH-70_AWB_2024_06_04_v12.onnx',
    flav_names = ["outputDiffAA"],
)

pfPNetHto4bMassDiffAARelHJetTags = boostedJetONNXJetTagsProducer.clone(
    src = 'pfParticleNetTagInfos',
    preprocess_json = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/diffAA_relH_regr_E15_mode0_wH-70_AWB_2024_06_04_v12.json',
    model_path = 'RecoBTag/Combined/data/ParticleNetAK8/Hto4bMassRegressionA/V02/diffAA_relH_regr_E15_mode0_wH-70_AWB_2024_06_04_v12.onnx',
    flav_names = ["outputDiffAARelH"],
)


from CommonTools.PileupAlgos.Puppi_cff import puppi
from PhysicsTools.PatAlgos.slimming.primaryVertexAssociation_cfi import primaryVertexAssociation

# This task is not used, useful only if we run it from RECO jets (RECO/AOD)
pfParticleNetTask = cms.Task(puppi, primaryVertexAssociation, pfParticleNetTagInfos,
                             pfParticleNetJetTags, pfMassDecorrelatedParticleNetJetTags, pfParticleNetMassRegressionJetTags,
                             pfParticleNetDiscriminatorsJetTags, pfMassDecorrelatedParticleNetDiscriminatorsJetTags)

# declare all the discriminators
# nominal: probs
_pfParticleNetJetTagsProbs = ['pfParticleNetJetTags:' + flav_name
                              for flav_name in pfParticleNetJetTags.flav_names]
# nominal: meta-taggers
_pfParticleNetJetTagsMetaDiscrs = ['pfParticleNetDiscriminatorsJetTags:' + disc.name.value()
                                   for disc in pfParticleNetDiscriminatorsJetTags.discriminators]
# mass-decorrelated: probs
_pfMassDecorrelatedParticleNetJetTagsProbs = ['pfMassDecorrelatedParticleNetJetTags:' + flav_name
                              for flav_name in pfMassDecorrelatedParticleNetJetTags.flav_names]
# mass-decorrelated: meta-taggers
_pfMassDecorrelatedParticleNetJetTagsMetaDiscrs = ['pfMassDecorrelatedParticleNetDiscriminatorsJetTags:' + disc.name.value()
                                   for disc in pfMassDecorrelatedParticleNetDiscriminatorsJetTags.discriminators]
# mass-decorrelated: H->aa->4b tagger
_pfPNetXto4bJetTagsProbs = ['pfPNetXto4bv1JetTags:' + flav_name
                            for flav_name in pfPNetXto4bv1JetTags.flav_names] + \
                           ['pfPNetXto4bv2aJetTags:' + flav_name
                            for flav_name in pfPNetXto4bv2aJetTags.flav_names] + \
                           ['pfPNetXto4bv2bJetTags:' + flav_name
                            for flav_name in pfPNetXto4bv2bJetTags.flav_names] + \
                           ['pfPNetTTtoHadJetTags:' + flav_name
                            for flav_name in pfPNetTTtoHadJetTags.flav_names]

_pfParticleNetMassRegressionOutputs = ['pfParticleNetMassRegressionJetTags:' + flav_name
                                       for flav_name in pfParticleNetMassRegressionJetTags.flav_names]
_pfPNetHto4bMassRegs =  ['pfPNetHto4bMassHv2bJetTags:' + flav_name
                         for flav_name in pfPNetHto4bMassHv2bJetTags.flav_names] + \
                        ['pfPNetHto4bMassAaJetTags:' + flav_name
                         for flav_name in pfPNetHto4bMassAaJetTags.flav_names] + \
                        ['pfPNetHto34bMassAaJetTags:' + flav_name
                         for flav_name in pfPNetHto34bMassAaJetTags.flav_names] + \
                        ['pfPNetHto34bMassAbJetTags:' + flav_name
                         for flav_name in pfPNetHto34bMassAbJetTags.flav_names] + \
                        ['pfPNetHto34bMassAdJetTags:' + flav_name
                         for flav_name in pfPNetHto34bMassAdJetTags.flav_names] + \
                        ['pfPNetHto4bMassA1JetTags:' + flav_name
                         for flav_name in pfPNetHto4bMassA1JetTags.flav_names] + \
                        ['pfPNetHto4bMassA2JetTags:' + flav_name
                         for flav_name in pfPNetHto4bMassA2JetTags.flav_names] + \
                        ['pfPNetHto4bMassAAJetTags:' + flav_name
                         for flav_name in pfPNetHto4bMassAAJetTags.flav_names] + \
                        ['pfPNetHto4bMassDiffAAJetTags:' + flav_name
                         for flav_name in pfPNetHto4bMassDiffAAJetTags.flav_names] + \
                        ['pfPNetHto4bMassDiffAARelHJetTags:' + flav_name
                         for flav_name in pfPNetHto4bMassDiffAARelHJetTags.flav_names]

                        # ['pfPNetHto4bMassHv1JetTags:' + flav_name
                        #  for flav_name in pfPNetHto4bMassHv1JetTags.flav_names] + \
                        # ['pfPNetHto4bMassHv2aJetTags:' + flav_name
                        #  for flav_name in pfPNetHto4bMassHv2aJetTags.flav_names] + \
                        # ['pfPNetHto4bMassHv2cJetTags:' + flav_name
                        #  for flav_name in pfPNetHto4bMassHv2cJetTags.flav_names] + \
                        # ['pfPNetHto4bMassHv2dJetTags:' + flav_name
                        #  for flav_name in pfPNetHto4bMassHv2dJetTags.flav_names] + \
                        # ['pfPNetHto4bMassAbJetTags:' + flav_name
                        #  for flav_name in pfPNetHto4bMassAbJetTags.flav_names] + \
                        # ['pfPNetHto4bMassAcJetTags:' + flav_name
                        #  for flav_name in pfPNetHto4bMassAcJetTags.flav_names] + \
                        # ['pfPNetHto4bMassAdJetTags:' + flav_name
                        #  for flav_name in pfPNetHto4bMassAdJetTags.flav_names] + \
                        # ['pfPNetHto34bMassAcJetTags:' + flav_name
                        #  for flav_name in pfPNetHto34bMassAcJetTags.flav_names] + \

_pfParticleNetJetTagsAll = _pfParticleNetJetTagsProbs + _pfParticleNetJetTagsMetaDiscrs + \
    _pfMassDecorrelatedParticleNetJetTagsProbs + _pfMassDecorrelatedParticleNetJetTagsMetaDiscrs
