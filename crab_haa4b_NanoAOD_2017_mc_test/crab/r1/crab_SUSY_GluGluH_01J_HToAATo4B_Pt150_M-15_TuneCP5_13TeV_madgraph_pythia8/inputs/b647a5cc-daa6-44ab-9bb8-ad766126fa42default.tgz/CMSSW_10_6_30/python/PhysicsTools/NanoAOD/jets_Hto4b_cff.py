import FWCore.ParameterSet.Config as cms
from PhysicsTools.NanoAOD.common_cff import *

DEBUG = False

## Shorthand for strings in variable names
REG = "bDiscriminator('pfPNetHto4bMass"
REG34 = "bDiscriminator('pfPNetHto34bMass"
X4B = "bDiscriminator('pfPNetXto4b"
TT  = "bDiscriminator('pfPNetTTtoHadJetTags:prob"
JTO = "JetTags:output"
X4Bv1  = X4B+"v1JetTags:prob"
X4Bv2a = X4B+"v2aJetTags:prob"
X4Bv2b = X4B+"v2bJetTags:prob"

if DEBUG:
    print('\nXto4b taggers are: %s, %s, %s' % (X4Bv1, X4Bv2a, X4Bv2b))

X4Bv1_QCD  = "{0}QCD4b')+{0}QCD3b')+{0}QCD2b')+{0}QCD1b')+{0}QCD0b')".format(X4Bv1)
X4Bv2a_QCD = "{0}QCD4b')+{0}QCD3b')+{0}QCD2b2c')+{0}QCD2b')+{0}QCD1b')+{0}QCD0b')".format(X4Bv2a)
X4Bv2b_QCD = "{0}QCD4b')+{0}QCD3b')+{0}QCD2b2c')+{0}QCD2b')+{0}QCD1b')+{0}QCD0b')".format(X4Bv2b)
X4Bv2a_NR  = "{0}NR4b')+{0}NR3b')+{0}NR2b2c')+{0}NR2b')+{0}NR1b')+{0}NR0b')+{0}NRlep')".format(X4Bv2a)
X4Bv2b_NR  = "{0}NR4b')+{0}NR3b')+{0}NR2b2c')+{0}NR2b')+{0}NR1b')+{0}NR0b')+{0}NRlep')".format(X4Bv2b)
TT_QCD  = "{0}QCD0b')+{0}QCD1b')+{0}QCD2c')+{0}QCD2b')".format(TT)
TT_X    = "{0}X0b')+{0}X1b')+{0}X2c')+{0}X2b')+{0}X3q')+{0}X4q')".format(TT)
TT_T1b  = "{0}T1b2q')+{0}T1bb2q')+{0}T1bbb2q')+{0}T1b3q')".format(TT)
TT_T2b  = "{0}T2b1q')+{0}T2b2q')+{0}TTHad')".format(TT)
TT_bbqq = "{0}T2b2q')+{0}TTHad')".format(TT)


MH = ["{0}Hv2a{1}Hv2a')".format(REG, JTO),
      "{0}Hv2b{1}Hv2b')".format(REG, JTO),
      "exp({0}Hv2c{1}Hv2c'))".format(REG, JTO),
      "exp({0}Hv2d{1}Hv2d'))".format(REG, JTO)]
MA = ["{0}Aa{1}Aa')".format(REG, JTO),
      "{0}Ab{1}Ab')".format(REG, JTO),
      "exp({0}Ac{1}Ac'))".format(REG, JTO),
      "exp({0}Ad{1}Ad'))".format(REG, JTO)]
MA34 = ["{0}Aa{1}Aa')".format(REG34, JTO),
        "{0}Ab{1}Ab')".format(REG34, JTO),
        "exp({0}Ac{1}Ac'))".format(REG34, JTO),
        "exp({0}Ad{1}Ad'))".format(REG34, JTO)]

if DEBUG:
    print('\nHto4b mass regressors are:')
    print(MH)
    print(MA)

## Compute average and standard deviation of masses
MH_avg = "0.25*({0}+{1}+{2}+{3})".format(MH[0], MH[1], MH[2], MH[3])
MA_avg = "0.25*({0}+{1}+{2}+{3})".format(MA[0], MA[1], MA[2], MA[3])
MH_std = "sqrt(1.0/6.0)*sqrt("
MA_std = "sqrt(1.0/6.0)*sqrt("
for i in range(4):
    for j in range(4):
        if i >= j: continue
        MH_std += "({0} - {1})*({0} - {1}) + ".format(MH[i], MH[j])
        MA_std += "({0} - {1})*({0} - {1}) + ".format(MA[i], MA[j])
MH_std = MH_std[:-3]+")"
MA_std = MA_std[:-3]+")"

dRegH = "PNet H->aa->4b Higgs mass regression"
dRegA = "PNet H->aa->4b a boson mass regression"
dX4Bv1  = "Mass-deco multiclass PNet H->aa->4b tagger (v1)"
dX4Bv2a = "Mass-deco ultraclass PNet H->aa->4b tagger (v2a)"
dX4Bv2b = "Mass-deco ultraclass PNet H->aa->4b tagger (v2b)"
dTT = "PNet ttbar->AK8(hadrons) taggers"

DIV = " / max(0.000001, "
SCa = "1.0 - (acos((2*"
SCz = ")) - 1.0) / 3.14159265359)"

## Custom ParticleNet models for H-->aa--> 4b decay
fatJetHto4bTable = cms.EDProducer("SimpleCandidateFlatTableProducer",
    src = cms.InputTag("finalJetsAK8"),
    cut = cms.string(""), # selection cuts in slimmedJetsAK8Sel in nano_addHto4bPlus_cff.py
    name = cms.string("FatJet"),
    doc  = cms.string("finalJetsAK8, i.e. selected, corrected AK8 fat jets for boosted analysis"),
    singleton = cms.bool(False), # the number of entries is variable
    extension = cms.bool(True),
    variables = cms.PSet(
        ## Higgs mass regressors
        #PNet_massH_v1  = Var(REG+"Hv1"+JTO+"Hv1')",   float, doc=dRegH+" (mode 3), trained only on 4b" ,precision=10),
        #PNet_massH_v2a = Var(MH[0], float, doc=dRegH+" (mode 3)", precision=10),
        PNet_massH_v2b = Var(MH[1], float, doc=dRegH+" (mode 0)", precision=10),
        #PNet_massH_v2c = Var(MH[2], float, doc=dRegH+" (mode 3, log)", precision=10),
        #PNet_massH_v2d = Var(MH[3], float, doc=dRegH+" (mode 0, log)", precision=10),
        #PNet_massH_avg = Var(MH_avg, float, doc=dRegH+" (average)", precision=10),
        #PNet_massH_std = Var(MH_std, float, doc=dRegH+" (std dev)", precision=10),

        ## "a" boson mass regressors
        PNet_massAa = Var(MA[0], float, doc=dRegA+" (mode 3)", precision=10),
        #PNet_massAb = Var(MA[1], float, doc=dRegA+" (mode 0)", precision=10),
        #PNet_massAc = Var(MA[2], float, doc=dRegA+" (mode 3, log)", precision=10),
        #PNet_massAd = Var(MA[3], float, doc=dRegA+" (mode 0, log)", precision=10),
        #PNet_massA_avg = Var(MA_avg, float, doc=dRegA+" (average)", precision=10),
        #PNet_massA_std = Var(MA_std, float, doc=dRegA+" (std dev)", precision=10),

        PNet_34massAa = Var(MA34[0], float, doc=dRegA+" (mode 3), 3 or 4 GEN b", precision=10),
        PNet_34massAb = Var(MA34[1], float, doc=dRegA+" (mode 0), 3 or 4 GEN b", precision=10),
        #PNet_34massAc = Var(MA34[2], float, doc=dRegA+" (mode 3, log), 3 or 4 GEN b", precision=10),
        PNet_34massAd = Var(MA34[3], float, doc=dRegA+" (mode 0, log), 3 or 4 GEN b", precision=10),

        PNet_massA1 = Var(REG+"A1"+JTO+"A1')", float, doc="PNet H->a1a2->4b regression to mass[lowest-dR bbbar]", precision=10),
        PNet_massA2 = Var(REG+"A2"+JTO+"A2')", float, doc="PNet H->a1a2->4b regression to mass[non-low-dR bbbar]", precision=10),
        PNet_massAA = Var(REG+"AA"+JTO+"AA')", float, doc="PNet H->a1a2->4b regression to avg mass[a1, a2]", precision=10),
        PNet_dMassAA      = Var("exp(0.5*"+REG+"DiffAA"+JTO+"DiffAA'))", float, doc="PNet H->a1a2->4b regression to mass[a1-a2]", precision=10),
        PNet_dMassAA_relH = Var(REG+"DiffAARelH"+JTO+"DiffAARelH')", float, doc="PNet H->a1a2->4b regression to mass[a1-a1]/mass[H]", precision=10),

        ## Mass-decorrelated X-->a1a2-->4b taggers
        ## v1 : Original multi-class training vs QCD
        PNet_X4b_v1_Haa4b  = Var(X4Bv1+"Haa4b')",  float, doc=dX4Bv1, precision=10),
        PNet_X4b_v1_Haa3b  = Var(X4Bv1+"Haa3b')",  float, doc=dX4Bv1, precision=10),
        PNet_X4b_v1_Haa2b  = Var(X4Bv1+"Haa2b')",  float, doc=dX4Bv1, precision=10),
        PNet_X4b_v1_Haa01b = Var(X4Bv1+"Haa01b')", float, doc=dX4Bv1, precision=10),
        PNet_X4b_v1_QCD4b  = Var(X4Bv1+"QCD4b')",  float, doc=dX4Bv1, precision=10),
        PNet_X4b_v1_QCD3b  = Var(X4Bv1+"QCD3b')",  float, doc=dX4Bv1, precision=10),
        PNet_X4b_v1_QCD2b  = Var(X4Bv1+"QCD2b')",  float, doc=dX4Bv1, precision=10),
        PNet_X4b_v1_QCD1b  = Var(X4Bv1+"QCD1b')",  float, doc=dX4Bv1, precision=10),
        PNet_X4b_v1_QCD0b  = Var(X4Bv1+"QCD0b')",  float, doc=dX4Bv1, precision=10),

        PNet_X4b_v1_QCD           = Var(X4Bv1_QCD, float, doc="PNet X4b QCD sum (v1)", precision=10),
        PNet_X4b_v1_Haa4b_vs_QCD  = Var(X4Bv1+"Haa4b')"+DIV+X4Bv1+"Haa4b')+"+X4Bv1_QCD+")",
                                        float, doc="PNet X4b Haa4b vs QCD (v1)", precision=10),
        PNet_X4b_v1_Haa34b_vs_QCD = Var("("+X4Bv1+"Haa3b')+"+X4Bv1+"Haa4b'))"+DIV+X4Bv1+"Haa3b')+"+X4Bv1+"Haa4b')+"+X4Bv1_QCD+")",
                                        float, doc="PNet X4b Haa4b vs QCD (v1)", precision=10),
        PNet_X4b_v1_Haa4b_score   = Var(SCa+X4Bv1+"Haa4b')"+DIV+X4Bv1+"Haa4b')+"+X4Bv1_QCD+SCz,
                                        float, doc="PNet transformed X4b Haa4b vs QCD (v1)", precision=10),
        PNet_X4b_v1_Haa34b_score  = Var(SCa+"("+X4Bv1+"Haa3b')+"+X4Bv1+"Haa4b'))"+DIV+X4Bv1+"Haa3b')+"+X4Bv1+"Haa4b')+"+X4Bv1_QCD+SCz,
                                        float, doc="PNet transformed X4b Haa34b vs QCD (v1)", precision=10),

        ## Mass-decorrelated X-->a1a2-->4b taggers
        ## v2a : Ultra-class training vs QCD and non-resonant ttbar and Z, with signal weight = 5.0
        PNet_X4b_v2a_Haa4b   = Var(X4Bv2a+"Haa4b')",   float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_Haa3b   = Var(X4Bv2a+"Haa3b')",   float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_Haa2b   = Var(X4Bv2a+"Haa2b')",   float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_Haa01b  = Var(X4Bv2a+"Haa01b')",  float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_QCD4b   = Var(X4Bv2a+"QCD4b')",   float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_QCD3b   = Var(X4Bv2a+"QCD3b')",   float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_QCD2b2c = Var(X4Bv2a+"QCD2b2c')", float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_QCD2b   = Var(X4Bv2a+"QCD2b')",   float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_QCD1b   = Var(X4Bv2a+"QCD1b')",   float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_QCD0b   = Var(X4Bv2a+"QCD0b')",   float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_NR4b    = Var(X4Bv2a+"NR4b')",    float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_NR3b    = Var(X4Bv2a+"NR3b')",    float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_NR2b2c  = Var(X4Bv2a+"NR2b2c')",  float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_NR2b    = Var(X4Bv2a+"NR2b')",    float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_NR1b    = Var(X4Bv2a+"NR1b')",    float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_NR0b    = Var(X4Bv2a+"NR0b')",    float, doc=dX4Bv2a, precision=10),
        PNet_X4b_v2a_NRlep   = Var(X4Bv2a+"NRlep')",   float, doc=dX4Bv2a, precision=10),

        PNet_X4b_v2a_QCD           = Var(X4Bv2a_QCD, float, doc="PNet X4b QCD sum (v2a)", precision=10),
        PNet_X4b_v2a_NR            = Var(X4Bv2a_NR,  float, doc="PNet X4b non-resonant W/Z/top sum (v2a)", precision=10),
        PNet_X4b_v2a_Haa4b_vs_QCD  = Var(X4Bv2a+"Haa4b')"+DIV+X4Bv2a+"Haa4b')+"+X4Bv2a_QCD+")",
                                        float, doc="PNet X4b Haa4b vs QCD (v2a)", precision=10),
        PNet_X4b_v2a_Haa4b_vs_NR   = Var(X4Bv2a+"Haa4b')"+DIV+X4Bv2a+"Haa4b')+"+X4Bv2a_NR+")",
                                        float, doc="PNet X4b Haa4b vs non-resonant W/Z/top (v2a)", precision=10),
        PNet_X4b_v2a_Haa4b_vs_all  = Var(X4Bv2a+"Haa4b')"+DIV+X4Bv2a+"Haa4b')+"+X4Bv2a_QCD+"+"+X4Bv2a_NR+")",
                                        float, doc="PNet X4b Haa4b vs all background (v2a)", precision=10),
        PNet_X4b_v2a_Haa4b_score   = Var(SCa+X4Bv2a+"Haa4b')"+DIV+X4Bv2a+"Haa4b')+"+X4Bv2a_QCD+"+"+X4Bv2a_NR+SCz,
                                        float, doc="PNet transformed X4b Haa4b vs all background (v2a)", precision=10),
        PNet_X4b_v2a_Haa34b_vs_QCD = Var("("+X4Bv2a+"Haa3b')+"+X4Bv2a+"Haa4b'))"+DIV+X4Bv2a+"Haa3b')+"+X4Bv2a+"Haa4b')+"+X4Bv2a_QCD+")",
                                         float, doc="PNet X4b Haa34b vs QCD (v2a)", precision=10),
        PNet_X4b_v2a_Haa34b_vs_NR  = Var("("+X4Bv2a+"Haa3b')+"+X4Bv2a+"Haa4b'))"+DIV+X4Bv2a+"Haa3b')+"+X4Bv2a+"Haa4b')+"+X4Bv2a_NR+")",
                                         float, doc="PNet X4b Haa34b vs non-resonant W/Z/top (v2a)", precision=10),
        PNet_X4b_v2a_Haa34b_vs_all = Var("("+X4Bv2a+"Haa3b')+"+X4Bv2a+"Haa4b'))"+DIV+X4Bv2a+"Haa3b')+"+X4Bv2a+"Haa4b')+"+X4Bv2a_QCD+"+"+X4Bv2a_NR+")",
                                         float, doc="PNet X4b Haa34b vs all background (v2a)", precision=10),
        PNet_X4b_v2a_Haa34b_score  = Var(SCa+"("+X4Bv2a+"Haa3b')+"+X4Bv2a+"Haa4b'))"+DIV+X4Bv2a+"Haa3b')+"+X4Bv2a+"Haa4b')+"+X4Bv2a_QCD+"+"+X4Bv2a_NR+SCz,
                                         float, doc="PNet transformed X4b Haa43b vs all background (v2a)", precision=10),

        ## Mass-decorrelated X-->a1a2-->4b taggers
        ## v2b : Ultra-class training vs QCD and non-resonant ttbar and Z, with signal weight = 2.0
        PNet_X4b_v2b_Haa4b   = Var(X4Bv2b+"Haa4b')",   float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_Haa3b   = Var(X4Bv2b+"Haa3b')",   float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_Haa2b   = Var(X4Bv2b+"Haa2b')",   float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_Haa01b  = Var(X4Bv2b+"Haa01b')",  float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_QCD4b   = Var(X4Bv2b+"QCD4b')",   float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_QCD3b   = Var(X4Bv2b+"QCD3b')",   float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_QCD2b2c = Var(X4Bv2b+"QCD2b2c')", float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_QCD2b   = Var(X4Bv2b+"QCD2b')",   float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_QCD1b   = Var(X4Bv2b+"QCD1b')",   float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_QCD0b   = Var(X4Bv2b+"QCD0b')",   float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_NR4b    = Var(X4Bv2b+"NR4b')",    float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_NR3b    = Var(X4Bv2b+"NR3b')",    float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_NR2b2c  = Var(X4Bv2b+"NR2b2c')",  float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_NR2b    = Var(X4Bv2b+"NR2b')",    float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_NR1b    = Var(X4Bv2b+"NR1b')",    float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_NR0b    = Var(X4Bv2b+"NR0b')",    float, doc=dX4Bv2b, precision=10),
        PNet_X4b_v2b_NRlep   = Var(X4Bv2b+"NRlep')",   float, doc=dX4Bv2b, precision=10),

        PNet_X4b_v2b_QCD           = Var(X4Bv2b_QCD, float, doc="PNet X4b QCD sum (v2b)", precision=10),
        PNet_X4b_v2b_NR            = Var(X4Bv2b_NR,  float, doc="PNet X4b non-resonant W/Z/top sum (v2b)", precision=10),
        PNet_X4b_v2b_Haa4b_vs_QCD  = Var(X4Bv2b+"Haa4b')"+DIV+X4Bv2b+"Haa4b')+"+X4Bv2b_QCD+")",
                                        float, doc="PNet X4b Haa4b vs QCD (v2b)", precision=10),
        PNet_X4b_v2b_Haa4b_vs_NR   = Var(X4Bv2b+"Haa4b')"+DIV+X4Bv2b+"Haa4b')+"+X4Bv2b_NR+")",
                                        float, doc="PNet X4b Haa4b vs non-resonant W/Z/top (v2b)", precision=10),
        PNet_X4b_v2b_Haa4b_vs_all  = Var(X4Bv2b+"Haa4b')"+DIV+X4Bv2b+"Haa4b')+"+X4Bv2b_QCD+"+"+X4Bv2b_NR+")",
                                        float, doc="PNet X4b Haa4b vs all background (v2b)", precision=10),
        PNet_X4b_v2b_Haa4b_score   = Var(SCa+X4Bv2b+"Haa4b')"+DIV+X4Bv2b+"Haa4b')+"+X4Bv2b_QCD+"+"+X4Bv2b_NR+SCz,
                                        float, doc="PNet transformed X4b Haa4b vs all background (v2b)", precision=10),
        PNet_X4b_v2b_Haa34b_vs_QCD = Var("("+X4Bv2b+"Haa3b')+"+X4Bv2b+"Haa4b'))"+DIV+X4Bv2b+"Haa3b')+"+X4Bv2b+"Haa4b')+"+X4Bv2b_QCD+")",
                                         float, doc="PNet X4b Haa34b vs QCD (v2b)", precision=10),
        PNet_X4b_v2b_Haa34b_vs_NR  = Var("("+X4Bv2b+"Haa3b')+"+X4Bv2b+"Haa4b'))"+DIV+X4Bv2b+"Haa3b')+"+X4Bv2b+"Haa4b')+"+X4Bv2b_NR+")",
                                         float, doc="PNet X4b Haa34b vs non-resonant W/Z/top (v2b)", precision=10),
        PNet_X4b_v2b_Haa34b_vs_all = Var("("+X4Bv2b+"Haa3b')+"+X4Bv2b+"Haa4b'))"+DIV+X4Bv2b+"Haa3b')+"+X4Bv2b+"Haa4b')+"+X4Bv2b_QCD+"+"+X4Bv2b_NR+")",
                                         float, doc="PNet X4b Haa34b vs all background (v2b)", precision=10),
        PNet_X4b_v2b_Haa34b_score  = Var(SCa+"("+X4Bv2b+"Haa3b')+"+X4Bv2b+"Haa4b'))"+DIV+X4Bv2b+"Haa3b')+"+X4Bv2b+"Haa4b')+"+X4Bv2b_QCD+"+"+X4Bv2b_NR+SCz,
                                         float, doc="PNet transformed X4b Haa43b vs all background (v2b)", precision=10),

        ## ttbar --> AK8(hadrons) taggers, especially targeting AK8(bbqq) for lepton + AK8 control region
        PNet_TT_TTHad = Var(TT+"TTHad')", float, doc=dTT, precision=10),
        PNet_TT_T2b2q = Var(TT+"T2b2q')", float, doc=dTT, precision=10),
        PNet_TT_T2b1q = Var(TT+"T2b1q')", float, doc=dTT, precision=10),

        PNet_TT_T1b3q   = Var(TT+"T1b3q')",   float, doc=dTT, precision=10),
        PNet_TT_T1bbb2q = Var(TT+"T1bbb2q')", float, doc=dTT, precision=10),
        PNet_TT_T1bb2q  = Var(TT+"T1bb2q')",  float, doc=dTT, precision=10),
        PNet_TT_T1b2q   = Var(TT+"T1b2q')",   float, doc=dTT, precision=10),

        PNet_TT_X4q = Var(TT+"X4q')", float, doc=dTT, precision=10),
        PNet_TT_X3q = Var(TT+"X3q')", float, doc=dTT, precision=10),
        PNet_TT_X2b = Var(TT+"X2b')", float, doc=dTT, precision=10),
        PNet_TT_X2c = Var(TT+"X2c')", float, doc=dTT, precision=10),
        PNet_TT_X1b = Var(TT+"X1b')", float, doc=dTT, precision=10),
        PNet_TT_X0b = Var(TT+"X0b')", float, doc=dTT, precision=10),

        PNet_TT_QCD2b = Var(TT+"QCD2b')", float, doc=dTT, precision=10),
        PNet_TT_QCD2c = Var(TT+"QCD2c')", float, doc=dTT, precision=10),
        PNet_TT_QCD1b = Var(TT+"QCD1b')", float, doc=dTT, precision=10),
        PNet_TT_QCD0b = Var(TT+"QCD0b')", float, doc=dTT, precision=10),

        PNet_TT_QCD  = Var(TT_QCD,  float, doc=dTT, precision=10),
        PNet_TT_X    = Var(TT_X,    float, doc=dTT, precision=10),
        PNet_TT_T1b  = Var(TT_T1b,  float, doc=dTT, precision=10),
        PNet_TT_T2b  = Var(TT_T2b,  float, doc=dTT, precision=10),
        PNet_TT_bbqq = Var(TT_bbqq, float, doc=dTT, precision=10),

        PNet_TT_T2b_vs_01b = Var("("+TT_T2b+")"+DIV+TT_T2b+"+"+TT+"T1b2q')+"+TT_X+"+"+TT_QCD+")",
                                 float, doc=dTT, precision=10),
        PNet_TT_bbqq_vs_01b = Var("("+TT_bbqq+")"+DIV+TT_bbqq+"+"+TT+"T1b2q')+"+TT_X+"+"+TT_QCD+")",
                                  float, doc=dTT, precision=10),

    ) ## End cms.PSet(
) ## End cms.EDProducer(
