import FWCore.ParameterSet.Config as cms

patJetCountFilter = cms.EDFilter('PatJetCountFilter',
  src = cms.InputTag(''),
  minNumber = cms.uint32(0)
)
