import FWCore.ParameterSet.Config as cms

patJetDeepJetTableProducer = cms.EDProducer('PatJetDeepJetTableProducer',
  nameDeepJet = cms.string('Jet'),
  idx_nameDeepJet = cms.string('djIdx'),
  storeAK4Truth = cms.string('no'),
  genparticles = cms.InputTag('prunedGenParticles'),
  jets = cms.InputTag('slimmedJets'),
  tagInfo_src = cms.InputTag('pfDeepFlavourTagInfosWithDeepInfo')
)
