from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crab/r1'
config.General.requestName = 'SUSY_GluGluH_01J_HToAATo4B_Pt150_M-12_TuneCP5_13TeV_madgraph_pythia8'
config.section_('JobType')
config.JobType.outputFiles = ['PNet_v1_Skim.root']
config.JobType.numCores = 4
config.JobType.maxMemoryMB = 10000
config.JobType.scriptExe = 'crab_script.sh'
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'Nano_Hto4bPlus_2017MC_cfg.py'
config.JobType.inputFiles = ['crab_script.sh', 'Hto4b_postproc.py']
config.JobType.maxJobRuntimeMin = 1315
config.section_('Data')
config.Data.inputDataset = '/SUSY_GluGluH_01J_HToAATo4B_Pt150_M-12_TuneCP5_13TeV_madgraph_pythia8/RunIISummer20UL17MiniAODv2-106X_mc2017_realistic_v9-v1/MINIAODSIM'
config.Data.outputDatasetTag = 'r1'
config.Data.publication = False
config.Data.unitsPerJob = 100000
config.Data.splitting = 'EventAwareLumiBased'
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/group/phys_susy/HToaaTo4b/NanoAOD/2017/MC/PNet_v2_2024_11_22/'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
